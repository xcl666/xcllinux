
public class GreenTrafficLights extends TrafficLights {
	@Override
	public void shine() {
		System.out.println("�̵Ʒ����̹�");
	}
}
