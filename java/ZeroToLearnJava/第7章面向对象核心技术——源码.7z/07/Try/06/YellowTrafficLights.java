
public class YellowTrafficLights extends TrafficLights {
	@Override
	public void shine() {
		System.out.println("�ƵƷ����ƹ�");
	}
}
