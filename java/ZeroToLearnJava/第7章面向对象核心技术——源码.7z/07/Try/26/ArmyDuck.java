
interface RunningInWater {
	public void driveInWater();
}

interface RunningOnLand {
	public void driveOnLand();
}

public class ArmyDuck implements RunningInWater, RunningOnLand {
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void driveOnLand() {
		System.out.print("��ˮ�м�ʻ");
	}

	@Override
	public void driveInWater() {
		System.out.print("��½���ϼ�ʻ");
	}
	
	public static void main(String[] args) {
		ArmyDuck armyDuck = new ArmyDuck();
		armyDuck.setName("ˮ½���ܳ�");
		System.out.print(armyDuck.getName() + "�ȿ���");
		armyDuck.driveOnLand();
		System.out.print("��Ҳ����");
		armyDuck.driveInWater();
	}
}
