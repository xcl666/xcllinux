
public class Helicopter extends Plane implements Hover{
	public Helicopter(String type) {
		super(type);
	}

	@Override
	public String move() {
		return "��ͣ�ڰ����";
	}
	
	public static void main(String[] args) {
		Helicopter helicopter = new Helicopter("ֱ����");
		System.out.println(helicopter.takeOff() + "��" + helicopter.move());
	}
}
