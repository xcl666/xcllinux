
public interface Hover {
	public String move();
}
