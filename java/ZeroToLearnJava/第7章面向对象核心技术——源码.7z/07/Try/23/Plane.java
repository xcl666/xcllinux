
public class Plane {
	String type;

	public Plane(String type) {
		this.type = type;
	}
	
	public String takeOff() {
		return this.type + "���";
	}
}
