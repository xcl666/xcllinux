
class Person {
	public String introduce() {
		return "����XXX";
	}
}

public class Doctor extends Person {
	public String introduce() {
		return super.introduce() + "��ʿ";
	}

	public static void main(String[] args) {
		Person person = new Person();
		System.out.println(person.introduce());
		Doctor doctor = new Doctor();
		System.out.println(doctor.introduce());
	}
}
