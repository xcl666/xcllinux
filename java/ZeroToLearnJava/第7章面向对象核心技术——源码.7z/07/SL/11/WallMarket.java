
public class WallMarket extends Market {
	public void shop() {
		System.out.println(name + "ʵ��깺��" + goods);
	}
}
