
public class TaobaoMarket extends Market {
	public void shop() {
		System.out.println(name + "����" + goods);
	}
}
